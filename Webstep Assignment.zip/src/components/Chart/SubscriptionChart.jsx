import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend, Filler } from 'chart.js';
import { Box, IconButton } from '@mui/material';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import PanToolIcon from '@mui/icons-material/PanTool'; // Replacing HandIcon
import HomeIcon from '@mui/icons-material/Home';
import MenuIcon from '@mui/icons-material/Menu'; // For three-bar line

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend, Filler);

const SubscriptionChart = () => {
  const [activeIcon, setActiveIcon] = useState(null);

  const handleIconClick = (iconName) => {
    setActiveIcon(iconName);
  };

  const iconStyles = (iconName) => ({
    p: 0,
    width: '24px',
    height: '24px',
    borderRadius: '50%',
    color: activeIcon === iconName ? 'white' : 'blue',
    backgroundColor: activeIcon === iconName ? 'blue' : 'transparent',
    '&:hover': {
      backgroundColor: 'blue', // Blue background on hover
      color: 'white', // White icon color on hover
    }
  });

  const data = {
    labels: ['Jan 23', 'Apr 23', 'Jun 23', 'Sep 23', 'Nov 23'],
    datasets: [
      {
        data: [30, 60, 90, 120, 130],
        borderColor: 'skyblue',
        backgroundColor: 'rgba(139, 69, 19, 0.2)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      }
    ],
  };

  return (
    <Box
      sx={{
        width: '100%',
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        position: 'relative',
      }}
    >
      <Line
        data={data}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false, // Hide the legend
            },
            tooltip: {
              callbacks: {
                label: () => null, // Hide tooltips
              },
            },
          },
          scales: {
            x: {
              grid: {
                display: false,
              },
            },
            y: {
              grid: {
                color: 'rgba(0, 0, 0, 0.1)',
              },
              beginAtZero: true,
              ticks: {
                stepSize: 10, // Y-axis step size
              },
            },
          },
        }}
      />
      {/* Icons container */}
      <Box
        sx={{
          position: 'absolute',
          top: -20,
          right: 10,
          display: 'flex',
          flexDirection: 'row',
          gap: '10px',
          zIndex: 1,
        }}
      >
        <IconButton sx={iconStyles('zoomIn')} onClick={() => handleIconClick('zoomIn')}>
          <ZoomInIcon />
        </IconButton>
        <IconButton sx={iconStyles('zoomOut')} onClick={() => handleIconClick('zoomOut')}>
          <ZoomOutIcon />
        </IconButton>
        <IconButton sx={iconStyles('panTool')} onClick={() => handleIconClick('panTool')}>
          <PanToolIcon />
        </IconButton>
        <IconButton sx={iconStyles('home')} onClick={() => handleIconClick('home')}>
          <HomeIcon />
        </IconButton>
        <IconButton sx={iconStyles('menu')} onClick={() => handleIconClick('menu')}>
          <MenuIcon />
        </IconButton>
      </Box>
    </Box>
  );
};

export default SubscriptionChart;